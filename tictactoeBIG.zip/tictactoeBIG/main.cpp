#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Board {
public:
    char contents[9][3][3] = {{{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}},
                              {{' ', ' ', ' '},
                               {' ', ' ', ' '},
                               {' ', ' ', ' '}}}; //Array is 3d to account for sectors
    void printBoard(){
        int ctr, ctr2, ctr3, ctr4, ctrFuel = 3, sideNum = 1; //ctrFuel and ctr4 break up the 9 sectors into 3 groups, making for a cleaner print
        cout << "0 | 1 2 3 | 1 2 3 | 1 2 3 |";
        for(ctr4 = 0; ctr4 < 3; ctr4++, ctrFuel += 3){
            cout << "\n----------------------------";
            for (ctr = 0; ctr < 3; ctr++) {
                cout << endl << sideNum << " | ";
                sideNum++;
                for (ctr2 = (ctrFuel - 3); ctr2 < ctrFuel; ctr2++) {
                    for (ctr3 = 0; ctr3 < 3; ctr3++) {
                        cout << contents[ctr2][ctr][ctr3] << " ";
                    }
                    cout << "| ";
                }
            }
            sideNum = 1;
        }

    }
    void clear(){ //Empties the board
        int ctr, ctr2, ctr3;
        for(ctr = 0; ctr < 9; ctr++){
            for(ctr2 = 0; ctr2 < 3; ctr2++){
                for(ctr3 = 0; ctr3 < 3; ctr3++) contents[ctr][ctr2][ctr3] = ' ';
            }

        }
    }
};

bool winCheck(char player, int sector, Board &mainBoard){ //Checking for wins within the current sector
    if(mainBoard.contents[sector][0][0] == player && mainBoard.contents[sector][0][1] == player && mainBoard.contents[sector][0][2] == player) return true;
    else if (mainBoard.contents[sector][1][0] == player && mainBoard.contents[sector][1][1] == player && mainBoard.contents[sector][1][2] == player) return true;
    else if (mainBoard.contents[sector][2][0] == player && mainBoard.contents[sector][2][1] == player && mainBoard.contents[sector][2][2] == player) return true;
    else if (mainBoard.contents[sector][0][0] == player && mainBoard.contents[sector][1][0] == player && mainBoard.contents[sector][2][0] == player) return true;
    else if (mainBoard.contents[sector][0][1] == player && mainBoard.contents[sector][1][1] == player && mainBoard.contents[sector][2][1] == player) return true;
    else if (mainBoard.contents[sector][0][2] == player && mainBoard.contents[sector][1][2] == player && mainBoard.contents[sector][2][2] == player) return true;
    else if (mainBoard.contents[sector][0][0] == player && mainBoard.contents[sector][1][1] == player && mainBoard.contents[sector][2][2] == player) return true;
    else if (mainBoard.contents[sector][0][2] == player && mainBoard.contents[sector][1][1] == player && mainBoard.contents[sector][2][0] == player) return true;
    return false;
}

bool grandWinCheck(vector<int> sectorsWon){ //Checking for 3 in a row sector wins
    if(find(sectorsWon.begin(), sectorsWon.end(), 0) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 1) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 2) != sectorsWon.end()) return true; //Uses method described at: https://stackoverflow.com/a/571405
    else if(find(sectorsWon.begin(), sectorsWon.end(), 3) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 4) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 5) != sectorsWon.end()) return true;
    else if(find(sectorsWon.begin(), sectorsWon.end(), 6) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 7) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 8) != sectorsWon.end()) return true;
    else if(find(sectorsWon.begin(), sectorsWon.end(), 0) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 3) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 6) != sectorsWon.end()) return true;
    else if(find(sectorsWon.begin(), sectorsWon.end(), 1) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 4) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 7) != sectorsWon.end()) return true;
    else if(find(sectorsWon.begin(), sectorsWon.end(), 2) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 5) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 8) != sectorsWon.end()) return true;
    else if(find(sectorsWon.begin(), sectorsWon.end(), 0) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 4) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 8) != sectorsWon.end()) return true;
    else if(find(sectorsWon.begin(), sectorsWon.end(), 2) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 4) != sectorsWon.end() && find(sectorsWon.begin(), sectorsWon.end(), 6) != sectorsWon.end()) return true;
    return false;
}

void gameStart(Board &mainBoard){ //This function runs all the actual game code
    char currentPlayer = 'X', winner;
    int input, sector, row, column, ctr, ctr2;
    vector<int> XSectorsWon, OSectorsWon;
    bool win, valid = false;
    string ans;
    cout << "Would you like to start a new game? (yes/no)" << endl;
    cin >> ans;
    if(ans == "yes" || ans == "Yes" || ans == "YES"){
        mainBoard.clear();
        for(ctr = 0; ctr < XSectorsWon.size(); ctr++) XSectorsWon.pop_back();
        for(ctr = 0; ctr < OSectorsWon.size(); ctr++) OSectorsWon.pop_back();
        win = false;
    }
    else return;
    while(!win){
        mainBoard.printBoard();
        cout << "\nPlayer " << currentPlayer << ", please enter what sector you would like to place a token in:" << endl;
        while(!valid){ //This makes sure that the user input is valid and not slop or out of bounds
            cin >> input;
            if(input > 0 && input < 10){
                valid = true;
                sector = input - 1; //All inputs are entered with a -1 since arrays start at 0 and not 1
            }
            else cout << "Sorry, but that is not a valid sector. Please try again." << endl;
        }
        valid = false;
        cout << "What row would you like to place a token in?" << endl;
        while(!valid){
            cin >> input;
            if(input > 0 && input < 4){
                valid = true;
                row = input - 1;
            }
            else cout << "Sorry, but that is not a valid row. Please try again." << endl;
        }
        valid = false;
        cout << "And what column?" << endl;
        while(!valid){
            cin >> input;
            if(input > 0 && input < 4){
                valid = true;
                column = input - 1;
            }
            else cout << "Sorry, but that is not a valid column. Please try again." << endl;
        }
        valid = false;
        if(mainBoard.contents[sector][row][column] != 'X' && mainBoard.contents[sector][row][column] != 'O'){ //For some reason checking for ' ' didn't work, but this way did. So.
            mainBoard.contents[sector][row][column] = currentPlayer; //Sets the selected tile to either X or O
            if(winCheck(currentPlayer,sector,mainBoard) && currentPlayer == 'X'){
                XSectorsWon.push_back(sector); //Each player has a list of sectors won. These sectors are checked in grandWinCheck
                for(ctr = 0; ctr < 3; ctr++){
                    for(ctr2 = 0; ctr2 < 3; ctr2++) mainBoard.contents[sector][ctr][ctr2] = currentPlayer;
                }
                if(grandWinCheck(XSectorsWon)){
                    winner = 'X';
                    win = true;
                }
            }
            else if(winCheck(currentPlayer,sector,mainBoard) && currentPlayer == 'O'){
                OSectorsWon.push_back(sector);
                for(ctr = 0; ctr < 3; ctr++){
                    for(ctr2 = 0; ctr2 < 3; ctr2++) mainBoard.contents[sector][ctr][ctr2] = currentPlayer;
                }
                if(grandWinCheck(OSectorsWon)){
                    winner = 'O';
                    win = true;
                }
            }
            if(currentPlayer == 'X') currentPlayer = 'O';
            else currentPlayer = 'X';
        }
        else cout << "That spot is taken. Please try again." << endl;
        sector = 0;
        row = 0;
        column = 0;
        input = -1; //No idea why I did this. Changing may break something
    }
    cout << "Game Over! Player " << winner << " wins!" << endl;
    mainBoard.printBoard();
}

int main() {
    Board mainBoard; //Using a class here makes calling some functions easier down the line
    cout << "Welcome to TIC TAC TOE x3!\n--------------------------" << endl;
    gameStart(mainBoard);
    return 0;
}
